# hosts/nixos/hardware-configuration.nix
# Substitua pelo conteúdo do seu hardware-configuration.nix real
# (estava na raiz do seu backup)

{ ... }: {}
